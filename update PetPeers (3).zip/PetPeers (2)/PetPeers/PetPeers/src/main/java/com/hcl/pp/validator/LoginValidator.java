package com.hcl.pp.validator;

import org.springframework.validation.Errors;
import org.springframework.validation.ValidationUtils;
import org.springframework.validation.Validator;

import com.hcl.pp.model.User;

public class LoginValidator implements Validator {
	/*
	 * To validate login form fields 1. All fields are mandatory -
	 * MandatoryField 2. If user name and password values do not match, error
	 * message is displayed - Either User Name or Password or both are invalid
	 */
	@Override
	public boolean supports(Class<?> paramClass) {
		return User.class.equals(paramClass);
	}

	@Override
	public void validate(Object obj, Errors errors) {
		// ValidationUtils.rejectIfEmptyOrWhitespace(errors, "id",
		// "id.required");

		/*
		 * User emp = (User) obj; if (emp.getId() <= 0) {
		 * errors.rejectValue("id", "negativeValue", new Object[] { "'id'" },
		 * "id can't be negative"); }
		 */

		ValidationUtils.rejectIfEmptyOrWhitespace(errors, "username", "username.required");
		ValidationUtils.rejectIfEmptyOrWhitespace(errors, "userpassword", "userPassword.required");
		/*
		 * ValidationUtils.rejectIfEmptyOrWhitespace(errors, "confirmPassword",
		 * "confirmPassword.required");
		 */
	}

}
