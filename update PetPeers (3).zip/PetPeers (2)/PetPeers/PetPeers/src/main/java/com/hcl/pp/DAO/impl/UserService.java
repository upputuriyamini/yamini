package com.hcl.pp.DAO.impl;

public interface UserService {
	public void addUser();
	public void updateUser();

}
