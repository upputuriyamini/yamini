package com.hcl.pp.services;

import com.hcl.pp.DAO.impl.SecurityService;

public class SecurityServiceImpl implements SecurityService {

}
