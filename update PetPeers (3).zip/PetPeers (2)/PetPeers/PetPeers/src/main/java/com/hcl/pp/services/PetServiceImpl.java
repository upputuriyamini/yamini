package com.hcl.pp.services;

import com.hcl.pp.DAO.impl.PetService;

public class PetServiceImpl implements PetService {

	@Override
	public void savePet() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void getAllPets() {
		// TODO Auto-generated method stub
		
	}

}
