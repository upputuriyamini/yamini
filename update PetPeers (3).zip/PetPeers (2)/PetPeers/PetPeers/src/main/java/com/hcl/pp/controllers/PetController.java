package com.hcl.pp.controllers;

import java.util.HashMap;
import java.util.Map;

import javax.validation.Valid;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.hcl.pp.DAO.impl.PetDAO;
import com.hcl.pp.model.Pet;

@Controller
public class PetController {
	private PetDAO petdao;
	@RequestMapping(value = "/saveContact", method = RequestMethod.POST)
	public ModelAndView saveContact(@ModelAttribute Pet pet) {
		petdao.savePet(pet);
	    return new ModelAndView("redirect:/");
	}
	/*private static final Logger logger = LoggerFactory.getLogger(UserController.class);

	private Map<String, Pet> pet = null;

	public PetController() {
		pet = new HashMap<String, Pet>();
	}

	@RequestMapping(value = "/pet", method = RequestMethod.GET)
	public String register() {
		return "pet_home";
	}

	@RequestMapping(value = "/pet/save", method = RequestMethod.GET)
	public String saveCustomerPage(Model model) {
		logger.info("Returning pet_home.jsp page");
		model.addAttribute("pet", new Pet());
		return "pet_home";
	}

	@RequestMapping(value = "/pet/save.do", method = RequestMethod.POST)
	public String saveCustomerAction(@Valid Pet user, BindingResult bindingResult, Model model) {
		if (bindingResult.hasErrors()) {
			logger.info("Returning pet_home.jsp page");
			return "pet_home";
		}
		logger.info("Returning pet_form.jsp page");
		model.addAttribute("user", user);
		// user.put(user.getUsername(), user);
		return "pet_form";
	}

*/}
