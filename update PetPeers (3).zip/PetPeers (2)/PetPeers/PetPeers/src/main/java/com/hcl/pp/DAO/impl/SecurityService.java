package com.hcl.pp.DAO.impl;

public interface SecurityService {

}
