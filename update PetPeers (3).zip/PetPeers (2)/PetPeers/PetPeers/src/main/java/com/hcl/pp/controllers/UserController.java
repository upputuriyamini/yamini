package com.hcl.pp.controllers;

import java.util.HashMap;
import java.util.Map;

import javax.validation.Valid;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.validation.Validator;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.annotation.InitBinder;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.hcl.pp.model.User;
import com.hcl.pp.services.UserDAOImpl;


@Controller
public class UserController<UserDAO> {
	private static final Logger logger = LoggerFactory.getLogger(UserController.class);

	private Map<String, User> user = null;
	@Autowired
	public UserDAOImpl customer;
	
	@Qualifier("UserValidator")

	private Validator validator;

	@InitBinder
	private void initBinder(WebDataBinder binder) {
		binder.setValidator(validator);
	}

	public UserController() {
		user = new HashMap<String, User>();
	}

	@ModelAttribute("user")
	public User createUserModel() {
		// ModelAttribute value should be same as used in the empSave.jsp
		return new User();
	}


	@RequestMapping(value = "/user", method = RequestMethod.GET)
	public String register() {
		return "userregn";
	}

	@RequestMapping(value = "/user/save", method = RequestMethod.GET)
	public String saveCustomerPage(Model model) {
		logger.info("Returning userregn.jsp page");
		model.addAttribute("user", new User());
		return "userregn";
	}

	@RequestMapping(value = "/user/save.do", method = RequestMethod.POST)
	public String saveCustomerAction(@Valid User user, BindingResult bindingResult, Model model) {
		customer.insert(user);
		if (bindingResult.hasErrors()) {
			logger.info("Returning userregn.jsp page");
			return "userregn";
		}
		logger.info("Returning registered.jsp page");
		model.addAttribute("user", user);
		// user.put(user.getUsername(), user);
		return "registered";
	}

	@RequestMapping(value = "/user/login", method = RequestMethod.GET)
	public String login(Model model) {
		model.addAttribute("login", new User());
		return "login";
	}
	@RequestMapping(value = "/pet_home", method = RequestMethod.GET)
	public String pet_home(Model model) {
		model.addAttribute("pet_home", new User());
		return "pet_home";
	}

}
