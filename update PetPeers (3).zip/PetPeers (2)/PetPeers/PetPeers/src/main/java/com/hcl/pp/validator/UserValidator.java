package com.hcl.pp.validator;

import org.springframework.validation.Errors;
import org.springframework.validation.ValidationUtils;
import org.springframework.validation.Validator;

import com.hcl.pp.model.User;

public class UserValidator implements Validator {
	/*
	 * To validate user registration form fields 1. All fields are mandatory�
	 * Mandatory Field 2. Make sure user name is unique- User Name already in
	 * use. Please select a different User Name 3. Password and Confirm Password
	 * values should match-Passwords do not match
	 * 
	 */
	@Override
	public boolean supports(Class<?> paramClass) {
		return User.class.equals(paramClass);
	}

	@Override
	public void validate(Object obj, Errors errors) {
		ValidationUtils.rejectIfEmptyOrWhitespace(errors, "username", "username.required");
		ValidationUtils.rejectIfEmptyOrWhitespace(errors, "userPassword", "userPassword.required");
		ValidationUtils.rejectIfEmptyOrWhitespace(errors, "confirmPassword", "confirmPassword.required");
		User emp = (User) obj;
		if (!(emp.getUserPassword().equals(emp.getConfirmPassword()))) {
			errors.rejectValue("userPassword", "notmatch.userPassword", "userPassword and confirmPassword is not matching");
		}
		

	}
}
