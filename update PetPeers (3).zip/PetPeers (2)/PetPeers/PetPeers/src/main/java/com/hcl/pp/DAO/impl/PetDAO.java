package com.hcl.pp.DAO.impl;

import org.springframework.web.bind.annotation.InitBinder;

import com.hcl.pp.model.Pet;

public interface PetDAO {
	public void getPetById(long petId);
	public void savePet(Pet pet);
	public void fetchAll(Pet pet);

}
