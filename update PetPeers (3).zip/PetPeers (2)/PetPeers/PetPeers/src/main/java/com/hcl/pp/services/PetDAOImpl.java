package com.hcl.pp.services;

import javax.sql.DataSource;

import org.springframework.jdbc.core.JdbcTemplate;

import com.hcl.pp.DAO.impl.PetDAO;
import com.hcl.pp.model.Pet;

public class PetDAOImpl implements PetDAO {
	private JdbcTemplate jdbcTemplate;
	 
    public void PetDAOImpl(DataSource dataSource) {
        jdbcTemplate = new JdbcTemplate(dataSource);
    }

	@Override
	public void getPetById(long petId) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void savePet(Pet pet) {
		// TODO Auto-generated method stub
	    if (pet.getId() > 0) {
	        // update
	        String sql = "UPDATE contact SET pet_name=?, pet_place=?, pet_age=?,pet_owner=?, "
	                    + "WHERE pet_id=?";
	        jdbcTemplate.update(sql);
	        /*(sql, pet.getName(), pet.getAge(),
	                pet.getPlace(),pet.getId());
	 */   } else {
	        // insert
	        String sql = "INSERT INTO contact (name, place, age, owner)"
	                    + " VALUES (?, ?, ?, ?)";
	        jdbcTemplate.update(sql);
	        /*.update(sql, pet.getName(), pet.getPlace(),
	                pet.getAge(),pet.getOwner(),pet.getId());
	   */ }
	 

	}

	@Override
	public void fetchAll(Pet pet) {
		// TODO Auto-generated method stub
		
	}

	}
