package com.hcl.pp.services;

import org.springframework.jdbc.core.support.JdbcDaoSupport;

import com.hcl.pp.DAO.impl.UserDAO;
import com.hcl.pp.model.User;

public class UserDAOImpl extends JdbcDaoSupport implements UserDAO {

	@Override
	public void insert(User user) {
		// TODO Auto-generated method stub
		String sql = "INSERT INTO pet_user " +
				"(user_name,user_passwd)VALUES (?, ?)";
				 
			getJdbcTemplate().update(sql, new Object[] { user.getUsername(),user.getUserPassword() 
			});
			
	}

	}
