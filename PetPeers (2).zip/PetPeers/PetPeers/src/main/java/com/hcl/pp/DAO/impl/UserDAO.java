package com.hcl.pp.DAO.impl;

import com.hcl.pp.model.User;

public interface UserDAO {
	public void insert(User user);
	/*public void addUser();
	public void updateUser();
	public void listUsers();
	public void getUserById();
	public void findByUserName();
	public void removeUser();
	public void authenticateUser();
	public void buyPet();
	public void getMyPets();
*/
}
