package com.hcl.pp.validator;

import org.springframework.validation.Errors;
import org.springframework.validation.ValidationUtils;
import org.springframework.validation.Validator;

import com.hcl.pp.model.Pet;

public class PetValidator implements Validator {
	/*
	 * To validate entry of a new Pet 1. All Fields are mandatory - Mandatory
	 * Field \ 2. Age filed should be numeric between 0 and 99. � Age should be
	 * 0 and 99 years
	 */
	@Override
	public boolean supports(Class<?> paramClass) {
		return Pet.class.equals(paramClass);
	}

	@Override
	public void validate(Object obj, Errors errors) {

		Pet emp = (Pet) obj;
		if (emp.getId() <= 0) {
			errors.rejectValue("id", "negativeValue", new Object[] { "'id'" }, "id can't be negative");
		}

		ValidationUtils.rejectIfEmptyOrWhitespace(errors, "name", "name.required");
		ValidationUtils.rejectIfEmptyOrWhitespace(errors, "age", "age.required");
		ValidationUtils.rejectIfEmptyOrWhitespace(errors, "place", "place.required");
	}
}
