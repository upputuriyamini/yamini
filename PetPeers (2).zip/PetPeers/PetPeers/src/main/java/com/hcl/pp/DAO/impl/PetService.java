package com.hcl.pp.DAO.impl;

public interface PetService {
	public void savePet();
	public void getAllPets();

}
