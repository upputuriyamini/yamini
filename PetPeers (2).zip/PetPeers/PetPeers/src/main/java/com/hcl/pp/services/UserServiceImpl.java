package com.hcl.pp.services;

import org.springframework.jdbc.core.simple.SimpleJdbcDaoSupport;

import com.hcl.pp.DAO.impl.UserService;

public class UserServiceImpl  extends SimpleJdbcDaoSupport implements UserService {

	@Override
	public void addUser() {
		// TODO Auto-generated method stub
		
	}

	public void updateUser(long id,String username,String userpassword) {
		// TODO Auto-generated method stub
		String sql = "update petdb set user_name=\"" +username+"\",user_password="+userpassword+ " where usert_id="+id;
		getJdbcTemplate().update(sql);
	
	}

	@Override
	public void updateUser() {
		// TODO Auto-generated method stub
		
	}

}
