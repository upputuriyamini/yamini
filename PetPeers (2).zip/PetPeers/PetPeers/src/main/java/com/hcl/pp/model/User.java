package com.hcl.pp.model;

import java.util.Set;

import org.hibernate.validator.constraints.NotEmpty;

public class User {
	long id;
	@NotEmpty
	String username;
	@NotEmpty
	String userPassword;
	@NotEmpty
	String confirmPassword;
	public long getId() {
		return id;
	}
	public void setId(long id) {
		this.id = id;
	}
	public String getUsername() {
		return username;
	}
	public void setUsername(String username) {
		this.username = username;
	}
	
	public String getUserPassword() {
		return userPassword;
	}
	public void setUserPassword(String userPassword) {
		this.userPassword = userPassword;
	}
	public String getConfirmPassword() {
		return confirmPassword;
	}
	public void setConfirmPassword(String confirmPassword) {
		this.confirmPassword = confirmPassword;
	}

}
